create definer = root@localhost trigger insert_resa2
    before insert
    on reservation
    for each row
BEGIN
DECLARE varint INT;
SET varint = NEW.res_cli_id;

	if (SELECT COUNT(res_cli_id) FROM reservation
	where varint = res_cli_id) > 3
	then SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'impossible total reservation dépassée ';
	END if;
END;

