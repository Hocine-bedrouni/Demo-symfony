create view v_ch_ho_st as
select `hotel`.`chambre`.`cha_numero` AS `NO chambre`,
       `hotel`.`hotel`.`hot_nom`      AS `nom hotel`,
       `hotel`.`station`.`sta_nom`    AS `nom station`
from `hotel`.`chambre`
         join `hotel`.`hotel`
         join `hotel`.`station`
where `hotel`.`chambre`.`cha_hot_id` = `hotel`.`hotel`.`hot_id`
  and `hotel`.`hotel`.`hot_sta_id` = `hotel`.`station`.`sta_id`;

